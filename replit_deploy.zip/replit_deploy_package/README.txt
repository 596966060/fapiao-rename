【Replit 一键部署说明】

这个文件夹包含所有需要的文件来部署到Replit。

方法1：直接上传到Replit（推荐）
===============================
1. 进入 https://replit.com
2. 删除旧项目（如果有的话）
3. 点击 "New Repl"
4. 选择语言: Python
5. 项目名: invoice-tool
6. 点击 Create

7. 在Files区，删除默认的main.py

8. 上传这个文件夹中的所有文件：
   - app.py
   - requirements.txt
   - Procfile
   - .gitignore
   - templates/ (整个文件夹)

9. 点击 "Run"

10. 等待1-2分钟，OCR模型会初始化

11. 右边会显示 "Webview" 和网址
    点击网址就能开始使用了！

方法2：从GitHub导入（更简单）
===============================
1. 进入 https://replit.com
2. 删除旧项目
3. 点击 "Import from GitHub"
4. 输入: https://github.com/596966060/fapiao-rename
5. 点击 Import
6. Replit会自动拉取最新代码
7. 点击 Run

建议用方法2，这样以后有更新时，Replit可以自动同步。

测试验证
========
部署完成后，上传 screenshot-20260511-160543.png，应该看到：
✓ 日期: 2026-05-07
✓ 发票号: 26324000000154072606
✓ 金额: 6.31 元

如果识别结果还是空白，在Replit Shell运行：
python diagnose_replit.py

然后把输出结果提供给开发者。

问题排查
=========
- 如果显示 "OCR 还未初始化"，等待2-3分钟重试
- 如果文件上传失败，确保使用了 Chrome 或 Firefox
- 如果识别失败，检查图片质量（发票必须清晰可读）

支持的文件格式
==============
- PDF (.pdf)
- JPG/JPEG (.jpg, .jpeg)
- PNG (.png)
- BMP (.bmp)
- GIF (.gif)
- TIFF (.tiff, .tif)
- ZIP (.zip) - 可以包含多个上述格式的文件

特性
====
✓ 完全离线，无需API Key
✓ 支持批量上传
✓ 自动识别发票信息
✓ 自动重命名文件
✓ 批量下载结果
✓ 多人并发使用

完成!
